export const loginPageLogo = '.login_logo'
export const username = "[data-test='username']"
export const password = "[data-test='password']"
export const loginButton = "[data-test='login-button']"
export const loginPageBotImage = '.bot_column'
export const loginCredentials = '#login_credentials'
export const loginPasswordCredentials = '.login_password'
