export const title = '.title'
export const firstName = "[data-test='firstName']"
export const lastName = "[data-test='lastName']"
export const postalCode = "[data-test='postalCode']"
export const cancelButton = "[data-test='cancel']"
export const continueButton = "[data-test='continue']"
export const errorMessage = "[data-test='error']"
