export const title = '.title'
export const completeHeader = 'text=Thank you for your order!'
export const completeText = '.complete-text'
export const ponyExpressImage = "img[alt='Pony Express']"
export const backHomeButton = "[data-test='back-to-products']"
